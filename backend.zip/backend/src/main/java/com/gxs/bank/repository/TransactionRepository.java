package com.gxs.bank.repository;

import com.gxs.bank.model.Transaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, UUID> {
    Page<Transaction> findByAccountIdOrderByCreatedAtDesc(UUID accountId, Pageable pageable);
    List<Transaction> findTop10ByAccountIdOrderByCreatedAtDesc(UUID accountId);
    List<Transaction> findByAccountIdAndCreatedAtBetweenOrderByCreatedAtDesc(
            UUID accountId, LocalDateTime start, LocalDateTime end);
}
