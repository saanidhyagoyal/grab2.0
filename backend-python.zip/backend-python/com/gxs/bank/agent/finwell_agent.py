"""
FinWell Agent — Financial Wellness Coach for Gig Economy Workers.
Analyzes income, spending, and provides proactive financial guidance.

This agent works in two modes:
1. LLM-powered (when Gemini API key is available)
2. Rule-based (fallback for demo without API costs)
"""

from datetime import datetime
from typing import Optional

from com.gxs.bank.agent.reasoning_logger import ReasoningLogger, ReasoningSession
from com.gxs.bank.agent import tools
from com.gxs.bank.agent.llm_client import get_llm_client
from com.gxs.bank.agent.memory import get_memory


class FinWellAgent:
    """Financial Wellness Coach Agent — LLM-enhanced with rule-based fallback."""

    def __init__(self, user_id: str):
        self.user_id = user_id
        self.logger = ReasoningLogger()
        self.llm = get_llm_client()
        self.memory = get_memory()

    def handle_query(self, query: str, session: Optional[ReasoningSession] = None) -> dict:
        """Route a user query to the appropriate financial analysis."""
        if session is None:
            session = self.logger.create_session(self.user_id, query, "finwell_chat")

        query_lower = query.lower()

        # Intent classification
        session.add_step(
            action="Classify Intent",
            reasoning=f"Analyzing user query: '{query}' to determine financial analysis needed",
            tools_used=["intent_classifier"],
            agent_name="FinWell",
        )

        if any(kw in query_lower for kw in ["day off", "leave", "rest", "break", "skip"]):
            return self._handle_day_off(session)
        elif any(kw in query_lower for kw in ["save", "saving", "emergency", "goal", "target"]):
            return self._handle_savings(query_lower, session)
        elif any(kw in query_lower for kw in ["income", "earn", "earning", "how much", "salary", "predict"]):
            return self._handle_income(query_lower, session)
        elif any(kw in query_lower for kw in ["spend", "spending", "budget", "expense", "cost"]):
            return self._handle_spending(session)
        elif any(kw in query_lower for kw in ["balance", "account", "money"]):
            return self._handle_balance(session)
        elif any(kw in query_lower for kw in ["loan", "emi", "repay"]):
            return self._handle_loan(session)
        elif any(kw in query_lower for kw in ["advice", "help", "suggest", "recommend", "tip", "coach"]):
            return self._handle_overall_advice(session)
        else:
            return self._handle_overall_advice(session)

    def _handle_day_off(self, session: ReasoningSession) -> dict:
        """Analyze whether user can afford a day off."""
        session.add_step(
            action="Fetch Account Balance",
            reasoning="Need account balance to understand current financial position",
            tools_used=["get_account_balance"],
            agent_name="FinWell",
        )
        balance_data = tools.get_account_balance(self.user_id)

        session.add_step(
            action="Analyze Income Patterns",
            reasoning="Analyzing historical income to predict future earnings and day-off impact",
            tools_used=["get_income_summary"],
            agent_name="FinWell",
        )
        income_summary = tools.get_income_summary(self.user_id)

        session.add_step(
            action="Run Day-Off Affordability Model",
            reasoning=f"Running ML prediction model. Current balance: S${balance_data['total_balance']:,.2f}, "
                      f"Avg daily income: S${income_summary['avg_daily_income']:.2f}",
            tools_used=["can_afford_day_off", "predict_income"],
            agent_name="FinWell",
        )
        day_off = tools.can_afford_day_off(self.user_id)
        prediction = tools.predict_income(self.user_id, 7)

        session.add_step(
            action="Generate Recommendation",
            reasoning=f"Can afford day off: {day_off['can_afford']}. "
                      f"Weekly surplus: S${day_off['weekly_surplus']:.2f}. "
                      f"Recommended day: {day_off['recommended_day_off']}",
            tools_used=[],
            result={"can_afford": day_off["can_afford"], "recommended_day": day_off["recommended_day_off"]},
            agent_name="FinWell",
        )

        # Try LLM-enhanced response
        llm_response = self.llm.generate_response(
            "FinWell",
            "Can I take a day off?",
            {"day_off_analysis": day_off, "prediction": prediction, "balance": balance_data["total_balance"]},
            self.memory.get_history(self.user_id),
        )
        response = llm_response if llm_response else day_off["advice"]
        session.complete(response, actions=["day_off_analysis"])

        return {
            "response": response,
            "data": {
                "day_off_analysis": day_off,
                "income_prediction": prediction,
                "current_balance": balance_data["total_balance"],
            },
            "reasoning_session_id": session.session_id,
            "agent": "FinWell",
        }

    def _handle_savings(self, query: str, session: ReasoningSession) -> dict:
        """Handle savings-related queries."""
        session.add_step(
            action="Fetch Financial Position",
            reasoning="Retrieving account balance and income data to calculate savings potential",
            tools_used=["get_account_balance", "get_income_summary"],
            agent_name="FinWell",
        )
        balance_data = tools.get_account_balance(self.user_id)
        income_summary = tools.get_income_summary(self.user_id)

        # Extract target amount if mentioned
        target = 5000
        import re
        amounts = re.findall(r'\$?\s*(\d+[\d,]*)', query)
        if amounts:
            try:
                target = float(amounts[0].replace(",", ""))
            except ValueError:
                pass

        session.add_step(
            action="Calculate Savings Strategy",
            reasoning=f"Computing optimal savings plan. Current balance: S${balance_data['total_balance']:,.2f}, "
                      f"Monthly income: ~S${income_summary['total_income'] / 2:,.2f}, "
                      f"Savings rate: {income_summary['savings_rate']}%, Target: S${target:,.2f}",
            tools_used=["get_savings_recommendation"],
            agent_name="FinWell",
        )
        savings_rec = tools.get_savings_recommendation(
            self.user_id,
            current_balance=balance_data["total_balance"],
            target=target,
        )

        session.add_step(
            action="Generate Savings Advice",
            reasoning=f"Recommended monthly savings: S${savings_rec['recommended_monthly_savings']:.2f} "
                      f"({savings_rec['recommended_savings_percentage']}% of income). On track: {savings_rec['on_track']}",
            tools_used=[],
            result=savings_rec,
            agent_name="FinWell",
        )

        response = savings_rec["advice"]

        # Add spending reduction tip
        spending = tools.get_spending_breakdown(self.user_id)
        if spending["categories"]:
            top = spending["categories"][0]
            response += (
                f"\n\n💡 Tip: Your top spending category is **{top['category']}** "
                f"(S${top['amount']:.2f}, {top['percentage']}% of total). "
                f"Reducing this by 20% could boost your savings by S${top['amount'] * 0.2:.2f}/month."
            )

        # Try LLM-enhanced response
        llm_response = self.llm.generate_response(
            "FinWell",
            "savings advice",
            {"savings_recommendation": savings_rec, "income": income_summary, "spending": spending, "balance": balance_data["total_balance"]},
            self.memory.get_history(self.user_id),
        )
        if llm_response:
            response = llm_response

        session.complete(response, actions=["savings_analysis"])

        return {
            "response": response,
            "data": {
                "savings_recommendation": savings_rec,
                "income_summary": income_summary,
                "spending_breakdown": spending,
                "current_balance": balance_data["total_balance"],
            },
            "reasoning_session_id": session.session_id,
            "agent": "FinWell",
        }

    def _handle_income(self, query: str, session: ReasoningSession) -> dict:
        """Handle income-related queries."""
        session.add_step(
            action="Analyze Historical Income",
            reasoning="Pulling income data from gig work history to identify patterns",
            tools_used=["get_income_summary"],
            agent_name="FinWell",
        )
        income_summary = tools.get_income_summary(self.user_id)

        days = 7
        if "month" in query:
            days = 30
        elif "week" in query:
            days = 7

        session.add_step(
            action="Predict Future Income",
            reasoning=f"Running income prediction model for next {days} days. "
                      f"Historical average: S${income_summary['avg_daily_income']:.2f}/day",
            tools_used=["predict_income"],
            agent_name="FinWell",
        )
        prediction = tools.predict_income(self.user_id, days)

        session.add_step(
            action="Compile Income Report",
            reasoning=f"Prediction complete. {prediction['trend_description']}. "
                      f"Predicted total: S${prediction['total_predicted']:.2f} over {days} days",
            tools_used=[],
            result={"trend": prediction["trend"], "total": prediction["total_predicted"]},
            agent_name="FinWell",
        )

        response = (
            f"📊 **Income Forecast** ({days}-day outlook)\n\n"
            f"Your predicted total: **S${prediction['total_predicted']:,.2f}** "
            f"(avg S${prediction['avg_daily_predicted']:.2f}/day)\n\n"
            f"📈 {prediction['trend_description']}\n\n"
            f"**Income Breakdown (last 60 days):**\n"
        )
        for cat, amount in income_summary["income_by_category"].items():
            emoji = "🚗" if "RIDE" in cat else "🍔" if "FOOD" in cat else "🎁"
            response += f"  {emoji} {cat}: S${amount:,.2f}\n"

        response += f"\n💰 Net savings (60 days): S${income_summary['net_savings']:,.2f} ({income_summary['savings_rate']}%)"

        session.complete(response, actions=["income_analysis"])

        return {
            "response": response,
            "data": {
                "income_summary": income_summary,
                "prediction": prediction,
            },
            "reasoning_session_id": session.session_id,
            "agent": "FinWell",
        }

    def _handle_spending(self, session: ReasoningSession) -> dict:
        """Handle spending analysis queries."""
        session.add_step(
            action="Analyze Spending Patterns",
            reasoning="Breaking down spending by category to identify optimization opportunities",
            tools_used=["get_spending_breakdown", "get_income_summary"],
            agent_name="FinWell",
        )
        spending = tools.get_spending_breakdown(self.user_id)
        income = tools.get_income_summary(self.user_id)

        session.add_step(
            action="Identify Optimization Opportunities",
            reasoning=f"Total spending: S${spending['total_spending']:.2f}. "
                      f"Top category: {spending['top_category']}. "
                      f"Savings rate: {income['savings_rate']}%",
            tools_used=[],
            result=spending,
            agent_name="FinWell",
        )

        response = "📊 **Your Spending Breakdown**\n\n"
        emojis = {
            "FUEL": "⛽", "MEALS": "🍜", "RENT": "🏠", "PHONE_BILL": "📱",
            "GROCERIES": "🛒", "VEHICLE_MAINTENANCE": "🔧", "TRANSPORT_TOPUP": "🚇",
        }
        for cat in spending["categories"]:
            emoji = emojis.get(cat["category"], "💳")
            response += f"  {emoji} **{cat['category']}**: S${cat['amount']:,.2f} ({cat['percentage']}%)\n"

        response += f"\n**Total**: S${spending['total_spending']:,.2f}"
        response += f"\n**Savings Rate**: {income['savings_rate']}%"

        # Tips
        if income["savings_rate"] < 15:
            response += "\n\n⚠️ Your savings rate is below 15%. Consider reducing discretionary spending."
        elif income["savings_rate"] > 25:
            response += "\n\n✅ Great savings rate! You're building a healthy financial buffer."

        session.complete(response, actions=["spending_analysis"])

        return {
            "response": response,
            "data": {"spending": spending, "income_summary": income},
            "reasoning_session_id": session.session_id,
            "agent": "FinWell",
        }

    def _handle_balance(self, session: ReasoningSession) -> dict:
        """Handle balance queries."""
        session.add_step(
            action="Fetch Account Data",
            reasoning="Retrieving all account balances",
            tools_used=["get_account_balance"],
            agent_name="FinWell",
        )
        data = tools.get_account_balance(self.user_id)

        response = f"💰 **Account Balance**: S${data['total_balance']:,.2f}\n\n"
        for acc in data["accounts"]:
            response += f"  • {acc['type']} ({acc['account_number']}): S${acc['balance']:,.2f} [{acc['status']}]\n"

        session.complete(response, actions=["balance_check"])
        return {
            "response": response,
            "data": data,
            "reasoning_session_id": session.session_id,
            "agent": "FinWell",
        }

    def _handle_loan(self, session: ReasoningSession) -> dict:
        """Handle loan-related queries."""
        session.add_step(
            action="Fetch Loan Data",
            reasoning="Retrieving active loans and EMI status",
            tools_used=["get_loan_status"],
            agent_name="FinWell",
        )
        data = tools.get_loan_status(self.user_id)

        if not data["loans"]:
            response = "✅ You have no active loans. Your debt-free status is great for financial wellness!"
        else:
            response = "📋 **Your Loans**\n\n"
            for loan in data["loans"]:
                response += (
                    f"  • **{loan['type']}**: S${loan['outstanding']:,.2f} outstanding "
                    f"(EMI: S${loan['emi']:,.2f}/month, {loan['emis_paid']}/{loan['tenure_months']} paid) "
                    f"[{loan['status']}]\n"
                )

        session.complete(response, actions=["loan_check"])
        return {
            "response": response,
            "data": data,
            "reasoning_session_id": session.session_id,
            "agent": "FinWell",
        }

    def _handle_overall_advice(self, session: ReasoningSession) -> dict:
        """Provide comprehensive financial advice."""
        session.add_step(
            action="Gather Complete Financial Picture",
            reasoning="Collecting all financial data points for holistic advice",
            tools_used=["get_account_balance", "get_income_summary", "get_spending_breakdown", "get_loan_status"],
            agent_name="FinWell",
        )

        balance = tools.get_account_balance(self.user_id)
        income = tools.get_income_summary(self.user_id)
        spending = tools.get_spending_breakdown(self.user_id)
        loans = tools.get_loan_status(self.user_id)
        prediction = tools.predict_income(self.user_id, 7)

        session.add_step(
            action="Analyze Financial Health",
            reasoning=f"Balance: S${balance['total_balance']:,.2f}, "
                      f"Savings rate: {income['savings_rate']}%, "
                      f"Active loans: {len(loans['loans'])}, "
                      f"Income trend: {prediction['trend']}",
            tools_used=[],
            agent_name="FinWell",
        )

        # Build comprehensive advice
        response = "🧠 **Your Financial Health Report**\n\n"
        response += f"💰 Balance: **S${balance['total_balance']:,.2f}**\n"
        response += f"📈 Income trend: **{prediction['trend']}** ({prediction['trend_description']})\n"
        response += f"💵 Savings rate: **{income['savings_rate']}%**\n"
        response += f"📊 Predicted weekly income: **S${prediction['total_predicted']:,.2f}**\n\n"

        # Personalized tips
        response += "**🎯 Personalized Recommendations:**\n\n"

        tips = []
        if income["savings_rate"] < 10:
            tips.append("🔴 **URGENT**: Your savings rate is very low. Aim for at least 15%. Consider cutting your top spending category.")
        elif income["savings_rate"] < 20:
            tips.append("🟡 Your savings rate could be better. Try the **50/30/20 rule**: 50% needs, 30% wants, 20% savings.")
        else:
            tips.append("🟢 Great savings discipline! Consider starting a **Fixed Deposit** for higher returns.")

        if balance["total_balance"] < 1000:
            tips.append("🔴 **Emergency Fund Alert**: Your balance is low. Prioritize building a S$3,000 emergency buffer.")
        elif balance["total_balance"] < 5000:
            tips.append("🟡 Building momentum! Keep saving toward a S$5,000 emergency fund.")

        if prediction["trend"] == "DECLINING":
            tips.append("📉 Your income is trending down. Consider taking more peak-hour rides or GrabFood shifts.")
        elif prediction["trend"] == "GROWING":
            tips.append("📈 Income is growing — great time to increase savings allocation!")

        if loans["loans"]:
            total_emi = sum(l["emi"] for l in loans["loans"])
            tips.append(f"💳 You have S${total_emi:,.2f}/month in loan EMIs. If possible, pay extra to reduce interest.")

        for tip in tips:
            response += f"  {tip}\n\n"

        session.add_step(
            action="Deliver Advice",
            reasoning=f"Generated {len(tips)} personalized recommendations based on financial analysis",
            tools_used=[],
            result={"tips_count": len(tips)},
            agent_name="FinWell",
        )
        session.complete(response, actions=["comprehensive_advice"])

        return {
            "response": response,
            "data": {
                "balance": balance,
                "income_summary": income,
                "spending": spending,
                "loans": loans,
                "prediction": prediction,
            },
            "reasoning_session_id": session.session_id,
            "agent": "FinWell",
        }
