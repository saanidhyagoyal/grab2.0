"""
LLM Client — Gemini API wrapper for the Agentic Financial Intelligence Platform.
Provides optional LLM-powered natural language responses.
Falls back gracefully to rule-based responses when API key is not configured.
"""

import os
import json
from typing import Optional

# Try to import Gemini SDK
_GEMINI_AVAILABLE = False
try:
    import google.generativeai as genai
    _GEMINI_AVAILABLE = True
except ImportError:
    pass


class LLMClient:
    """
    Wrapper for Google Gemini (generative AI) API.
    Designed for graceful degradation — works without an API key.
    """

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "")
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
        self.enabled = False
        self.model = None

        if self.api_key and _GEMINI_AVAILABLE:
            try:
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel(self.model_name)
                self.enabled = True
                print(f"[LLMClient] ✅ Gemini ({self.model_name}) initialized successfully")
            except Exception as e:
                print(f"[LLMClient] ⚠️ Gemini initialization failed: {e}")
                self.enabled = False
        else:
            reason = "no API key" if not self.api_key else "google-generativeai not installed"
            print(f"[LLMClient] ℹ️ Running in rule-based mode ({reason})")

    def is_available(self) -> bool:
        """Check if LLM is available for use."""
        return self.enabled and self.model is not None

    def classify_intent(self, query: str, conversation_history: list = None) -> Optional[dict]:
        """
        Use LLM for intent classification.
        Returns None if LLM is unavailable (caller should use keyword fallback).
        """
        if not self.is_available():
            return None

        history_ctx = ""
        if conversation_history:
            recent = conversation_history[-5:]  # Last 5 turns
            history_ctx = "Recent conversation:\n" + "\n".join(
                f"- {'User' if m['role'] == 'user' else 'Agent'}: {m['content'][:100]}"
                for m in recent
            ) + "\n\n"

        prompt = f"""You are an intent classifier for a financial assistant serving gig economy workers (Grab drivers).

{history_ctx}User query: "{query}"

Classify this query into ONE of these intents:
- "day_off" - Asking about taking time off, rest, breaks
- "savings" - Savings goals, emergency fund, saving money
- "income" - Income analysis, earnings, salary, predictions
- "spending" - Spending breakdown, budget, expenses
- "balance" - Account balance check
- "loan" - Loan status, EMI information
- "fraud_scan" - Security scan, suspicious activity detection
- "freeze_card" - Freeze/block/lock cards
- "security_status" - Account security status check
- "recovery" - Account compromised, hacked, stolen
- "general_advice" - Financial advice, tips, recommendations
- "full_report" - Comprehensive financial health report

Respond ONLY with valid JSON:
{{"intent": "<intent_name>", "domain": "finwell|fraudshield|both", "confidence": "HIGH|MEDIUM|LOW"}}"""

        try:
            response = self.model.generate_content(
                prompt,
                generation_config=genai.GenerationConfig(
                    temperature=0.1,
                    max_output_tokens=100,
                ),
            )
            text = response.text.strip()
            # Clean markdown code blocks if present
            if text.startswith("```"):
                text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
            return json.loads(text)
        except Exception as e:
            print(f"[LLMClient] Intent classification failed: {e}")
            return None

    def generate_response(
        self,
        agent_name: str,
        query: str,
        tool_data: dict,
        conversation_history: list = None,
    ) -> Optional[str]:
        """
        Use LLM to generate a natural language response from tool data.
        Returns None if LLM is unavailable (caller should use rule-based response).
        """
        if not self.is_available():
            return None

        history_ctx = ""
        if conversation_history:
            recent = conversation_history[-5:]
            history_ctx = "Recent conversation:\n" + "\n".join(
                f"- {'User' if m['role'] == 'user' else 'Agent'}: {m['content'][:150]}"
                for m in recent
            ) + "\n\n"

        # Truncate tool data for prompt
        data_str = json.dumps(tool_data, indent=2, default=str)
        if len(data_str) > 3000:
            data_str = data_str[:3000] + "\n... (truncated)"

        if agent_name == "FinWell":
            persona = (
                "You are FinWell, a friendly financial wellness coach for gig economy workers. "
                "You're empathetic, concise, and actionable. Use emojis sparingly. "
                "Reference specific numbers from the data. Keep responses under 200 words. "
                "Use markdown formatting (bold, bullet points) for readability."
            )
        elif agent_name == "FraudShield":
            persona = (
                "You are FraudShield, an AI security agent protecting gig workers' finances. "
                "You're vigilant, clear, and reassuring. Flag genuine threats firmly but don't cause panic. "
                "Reference specific transaction details. Keep responses under 200 words. "
                "Use markdown formatting and risk emojis (🔴🟡🟢) for clarity."
            )
        else:
            persona = (
                "You are a financial AI supervisor coordinating FinWell and FraudShield agents. "
                "Provide a unified summary. Keep responses under 200 words."
            )

        prompt = f"""{persona}

{history_ctx}User's question: "{query}"

Here is the data from your analysis tools:
{data_str}

Generate a helpful, personalized response to the user. Be specific with numbers from the data.
Do NOT include any JSON or code blocks. Respond in plain markdown text only."""

        try:
            response = self.model.generate_content(
                prompt,
                generation_config=genai.GenerationConfig(
                    temperature=0.7,
                    max_output_tokens=500,
                ),
            )
            return response.text.strip()
        except Exception as e:
            print(f"[LLMClient] Response generation failed: {e}")
            return None

    def generate_insights_summary(self, insights: list) -> Optional[str]:
        """
        Use LLM to create a natural-sounding summary of proactive insights.
        Returns None if LLM is unavailable.
        """
        if not self.is_available():
            return None

        insights_str = json.dumps(insights, indent=2, default=str)

        prompt = f"""You are a financial AI assistant. Summarize these financial insights into a brief,
friendly notification message (2-3 sentences max):

{insights_str}

Be specific with numbers. Use one emoji at the start. Keep it conversational."""

        try:
            response = self.model.generate_content(
                prompt,
                generation_config=genai.GenerationConfig(
                    temperature=0.7,
                    max_output_tokens=150,
                ),
            )
            return response.text.strip()
        except Exception as e:
            print(f"[LLMClient] Insights summary failed: {e}")
            return None


# Singleton instance
_llm_client = None


def get_llm_client() -> LLMClient:
    """Get the singleton LLM client instance."""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client
