"""
Reasoning Logger — Records every step of agent decision-making.
This is a KEY deliverable the hackathon explicitly asks for:
  "A Reasoning Log showing how the agent thought through a specific problem"
"""

from datetime import datetime
from typing import Optional
import json
import uuid


class ReasoningStep:
    """A single step in the agent's reasoning chain."""

    def __init__(
        self,
        step_number: int,
        action: str,
        reasoning: str,
        tools_used: list = None,
        input_data: dict = None,
        result: dict = None,
        agent_name: str = "Supervisor",
    ):
        self.id = str(uuid.uuid4())
        self.step_number = step_number
        self.action = action
        self.reasoning = reasoning
        self.tools_used = tools_used or []
        self.input_data = input_data or {}
        self.result = result or {}
        self.agent_name = agent_name
        self.timestamp = datetime.utcnow()

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "step_number": self.step_number,
            "action": self.action,
            "reasoning": self.reasoning,
            "tools_used": self.tools_used,
            "input_data": self.input_data,
            "result": self.result,
            "agent_name": self.agent_name,
            "timestamp": self.timestamp.isoformat(),
        }


class ReasoningSession:
    """A complete reasoning session for one agent interaction."""

    def __init__(self, user_id: str, query: str, session_type: str = "chat"):
        self.session_id = str(uuid.uuid4())
        self.user_id = user_id
        self.query = query
        self.session_type = session_type  # "chat", "fraud_alert", "proactive_insight"
        self.steps: list[ReasoningStep] = []
        self.final_response: Optional[str] = None
        self.final_actions: list = []
        self.started_at = datetime.utcnow()
        self.completed_at: Optional[datetime] = None
        self.status = "in_progress"

    def add_step(
        self,
        action: str,
        reasoning: str,
        tools_used: list = None,
        input_data: dict = None,
        result: dict = None,
        agent_name: str = "Supervisor",
    ) -> ReasoningStep:
        step = ReasoningStep(
            step_number=len(self.steps) + 1,
            action=action,
            reasoning=reasoning,
            tools_used=tools_used,
            input_data=input_data,
            result=result,
            agent_name=agent_name,
        )
        self.steps.append(step)
        return step

    def complete(self, response: str, actions: list = None):
        self.final_response = response
        self.final_actions = actions or []
        self.completed_at = datetime.utcnow()
        self.status = "completed"

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "query": self.query,
            "session_type": self.session_type,
            "steps": [s.to_dict() for s in self.steps],
            "final_response": self.final_response,
            "final_actions": self.final_actions,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status,
            "total_steps": len(self.steps),
            "duration_ms": (
                int((self.completed_at - self.started_at).total_seconds() * 1000)
                if self.completed_at
                else None
            ),
        }


class ReasoningLogger:
    """
    Global reasoning logger. Stores sessions in-memory for demo.
    In production, this would persist to a database.
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._sessions = {}  # session_id -> ReasoningSession
            cls._instance._user_sessions = {}  # user_id -> [session_id, ...]
        return cls._instance

    def create_session(self, user_id: str, query: str, session_type: str = "chat") -> ReasoningSession:
        session = ReasoningSession(user_id, query, session_type)
        self._sessions[session.session_id] = session
        if user_id not in self._user_sessions:
            self._user_sessions[user_id] = []
        self._user_sessions[user_id].append(session.session_id)
        return session

    def get_session(self, session_id: str) -> Optional[ReasoningSession]:
        return self._sessions.get(session_id)

    def get_user_sessions(self, user_id: str, limit: int = 20) -> list:
        session_ids = self._user_sessions.get(user_id, [])
        sessions = [self._sessions[sid] for sid in reversed(session_ids) if sid in self._sessions]
        return [s.to_dict() for s in sessions[:limit]]

    def get_latest_session(self, user_id: str) -> Optional[dict]:
        sessions = self.get_user_sessions(user_id, limit=1)
        return sessions[0] if sessions else None

    def clear_user_sessions(self, user_id: str):
        if user_id in self._user_sessions:
            for sid in self._user_sessions[user_id]:
                self._sessions.pop(sid, None)
            del self._user_sessions[user_id]
