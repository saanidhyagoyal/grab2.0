"""
Agent Tools — Bridge between LangGraph agents and bank services.
Each tool is a callable that the agent can invoke to interact
with the bank's data layer (accounts, transactions, cards, etc.)
and the ML layer (anomaly detection, income prediction).
"""

from contextlib import contextmanager
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional

from com.gxs.bank.config.database import SessionLocal
from com.gxs.bank.ml.anomaly_detector import AnomalyDetector
from com.gxs.bank.ml.income_predictor import IncomePredictor
from com.gxs.bank.ml.mock_data_generator import (
    generate_transaction_history,
    generate_fraud_transactions,
    compute_income_summary,
)
from com.gxs.bank.model.Card import Card
from com.gxs.bank.model.Notification import Notification
from com.gxs.bank.model.Transaction import Transaction
from com.gxs.bank.repository.AccountRepository import AccountRepository
from com.gxs.bank.repository.CardRepository import CardRepository
from com.gxs.bank.repository.NotificationRepository import NotificationRepository
from com.gxs.bank.repository.TransactionRepository import TransactionRepository
from com.gxs.bank.repository.UserRepository import UserRepository
from com.gxs.bank.repository.LoanRepository import LoanRepository


# ── Singleton caches for ML models ──────────────────────────────────────────

_anomaly_detectors = {}  # user_id -> AnomalyDetector
_income_predictors = {}  # user_id -> IncomePredictor
_mock_txn_cache = {}     # user_id -> generated transactions


@contextmanager
def _get_db():
    """Context manager that ensures the DB session is always properly closed."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _ensure_mock_data(user_id: str) -> list:
    """Ensure mock transaction data exists for agent analysis."""
    if user_id not in _mock_txn_cache:
        txns = generate_transaction_history(days=60)
        fraud_txns = generate_fraud_transactions()
        _mock_txn_cache[user_id] = txns + fraud_txns
    return _mock_txn_cache[user_id]


def _ensure_anomaly_detector(user_id: str) -> AnomalyDetector:
    """Get or create a trained anomaly detector for a user."""
    if user_id not in _anomaly_detectors:
        detector = AnomalyDetector()
        mock_txns = _ensure_mock_data(user_id)
        normal_txns = [t for t in mock_txns if t.get("category") != "FRAUD_SUSPICIOUS"]
        detector.train(normal_txns)
        _anomaly_detectors[user_id] = detector
    return _anomaly_detectors[user_id]


def _ensure_income_predictor(user_id: str) -> IncomePredictor:
    """Get or create a trained income predictor for a user."""
    if user_id not in _income_predictors:
        predictor = IncomePredictor()
        mock_txns = _ensure_mock_data(user_id)
        predictor.train(mock_txns)
        _income_predictors[user_id] = predictor
    return _income_predictors[user_id]


# ═══════════════════════════════════════════════════════════════════════════════
#  BANK DATA TOOLS
# ═══════════════════════════════════════════════════════════════════════════════

def get_account_balance(user_id: str) -> dict:
    """Get all account balances for a user."""
    with _get_db() as db:
        accounts = AccountRepository(db).findByUserId(user_id)
        result = []
        for acc in accounts:
            result.append({
                "account_id": acc.id,
                "account_number": acc.accountNumber,
                "balance": float(acc.balance),
                "type": acc.accountType.value if acc.accountType else "SAVINGS",
                "status": acc.status.value if acc.status else "ACTIVE",
            })
        return {"accounts": result, "total_balance": sum(a["balance"] for a in result)}


def get_transaction_history(user_id: str, days: int = 30) -> dict:
    """Get real transaction history from the database."""
    with _get_db() as db:
        accounts = AccountRepository(db).findByUserId(user_id)
        all_txns = []
        for acc in accounts:
            txns_page = TransactionRepository(db).findByAccountIdOrderByCreatedAtDesc(acc.id, 0, 100)
            for txn in txns_page["content"]:
                all_txns.append({
                    "type": txn.type.value if txn.type else "DEBIT",
                    "amount": str(float(txn.amount)),
                    "description": txn.description,
                    "channel": txn.channel.value if txn.channel else "NET_BANKING",
                    "balance_after": str(float(txn.balanceAfter)),
                    "timestamp": txn.createdAt,
                    "reference": txn.referenceNumber,
                })
        return {"transactions": all_txns, "count": len(all_txns)}


def get_user_profile(user_id: str) -> dict:
    """Get user profile information."""
    with _get_db() as db:
        user = UserRepository(db).findById(user_id)
        if not user:
            return {"error": "User not found"}
        return {
            "name": user.fullName,
            "email": user.email,
            "kyc_status": user.kycStatus.value if user.kycStatus else "UNVERIFIED",
            "role": user.role.value if user.role else "CUSTOMER",
        }


def get_card_status(user_id: str) -> dict:
    """Get all cards and their statuses."""
    with _get_db() as db:
        cards = CardRepository(db).findByUserId(user_id)
        result = []
        for card in cards:
            result.append({
                "card_id": card.id,
                "last4": card.cardNumberLast4,
                "type": card.cardType.value if card.cardType else "DEBIT",
                "status": card.status.value if card.status else "ACTIVE",
                "network": card.cardNetwork.value if card.cardNetwork else "VISA",
                "daily_limit": float(card.dailyLimit),
                "international_enabled": card.isInternationalEnabled,
            })
        return {"cards": result}


def freeze_card(user_id: str, card_id: str) -> dict:
    """Freeze a card (fraud intervention action)."""
    with _get_db() as db:
        card = CardRepository(db).findById(card_id)
        if not card:
            return {"success": False, "error": "Card not found"}
        if card.userId != user_id:
            return {"success": False, "error": "Card does not belong to user"}
        if card.status == Card.Status.ACTIVE:
            card.status = Card.Status.FROZEN
            db.commit()
            return {"success": True, "message": f"Card ending {card.cardNumberLast4} has been frozen"}
        return {"success": False, "error": f"Card is already {card.status.value}"}


def create_security_notification(user_id: str, title: str, message: str) -> dict:
    """Create a security notification for the user."""
    with _get_db() as db:
        user = UserRepository(db).findById(user_id)
        if not user:
            return {"success": False, "error": "User not found"}
        notif = Notification(
            user=user,
            userId=user.id,
            title=title,
            message=message,
            type=Notification.Type.SECURITY,
            isRead=False,
        )
        NotificationRepository(db).save(notif)
        db.commit()
        return {"success": True, "notification_id": notif.id}


def get_loan_status(user_id: str) -> dict:
    """Get all loans for a user."""
    with _get_db() as db:
        loans = LoanRepository(db).findByUserId(user_id)
        result = []
        for loan in loans:
            result.append({
                "loan_id": loan.id,
                "type": loan.loanType.value if loan.loanType else "PERSONAL",
                "amount": float(loan.amount),
                "outstanding": float(loan.outstandingAmount),
                "emi": float(loan.monthlyPayment),
                "status": loan.status.value if loan.status else "ACTIVE",
                "tenure_months": loan.tenureMonths,
                "emis_paid": loan.emisPaid,
            })
        return {"loans": result}


# ═══════════════════════════════════════════════════════════════════════════════
#  ML / ANALYTICS TOOLS
# ═══════════════════════════════════════════════════════════════════════════════

def get_income_summary(user_id: str) -> dict:
    """Get income analysis from mock gig worker data."""
    mock_txns = _ensure_mock_data(user_id)
    return compute_income_summary(mock_txns)


def predict_income(user_id: str, days: int = 7) -> dict:
    """Predict future income using trained model."""
    predictor = _ensure_income_predictor(user_id)
    return predictor.predict_next_days(days)


def can_afford_day_off(user_id: str, monthly_expenses: float = 2000) -> dict:
    """Check if the gig worker can afford a day off."""
    predictor = _ensure_income_predictor(user_id)
    result = predictor.can_afford_day_off(monthly_expenses=monthly_expenses)
    # Add extra fields for dashboard display
    income_summary = get_income_summary(user_id)
    result["avg_daily_income"] = income_summary.get("avg_daily_income", 0)
    result["daily_expenses"] = round(monthly_expenses / 30, 2)
    balance = get_account_balance(user_id)
    surplus = balance.get("total_balance", 0) - monthly_expenses
    result["buffer_days"] = max(0, int(surplus / max(result["daily_expenses"], 1)))
    result["recommendation"] = result.get("advice", "")
    return result


def get_savings_recommendation(user_id: str, current_balance: float = None, target: float = 5000) -> dict:
    """Get personalized savings recommendation."""
    if current_balance is None:
        balance_data = get_account_balance(user_id)
        current_balance = balance_data.get("total_balance", 0)

    predictor = _ensure_income_predictor(user_id)
    result = predictor.get_savings_recommendation(current_balance, target)
    # Add extra fields for dashboard display
    result["target"] = target
    result["current_balance"] = current_balance
    result["recommended_daily_savings"] = round(result.get("recommended_monthly_savings", 0) / 30, 2)
    result["months_to_target"] = result.get("target_months", 6)
    result["is_achievable"] = result.get("on_track", True)
    return result


def detect_anomalies(user_id: str) -> dict:
    """Run anomaly detection on recent transactions."""
    detector = _ensure_anomaly_detector(user_id)
    mock_txns = _ensure_mock_data(user_id)

    # Score all transactions, focus on suspicious ones
    results = detector.batch_score(mock_txns)

    alerts = []
    for txn, score in zip(mock_txns, results):
        if score["is_anomaly"]:
            alerts.append({
                "transaction": {
                    "amount": txn["amount"],
                    "description": txn["description"],
                    "type": txn["type"],
                    "channel": txn.get("channel", "UNKNOWN"),
                    "timestamp": txn["timestamp"].isoformat() if isinstance(txn.get("timestamp"), datetime) else str(txn.get("timestamp", "")),
                },
                "risk_assessment": score,
            })

    return {
        "total_transactions_analyzed": len(mock_txns),
        "anomalies_detected": len(alerts),
        "alerts": alerts[:10],  # Top 10 alerts
        "risk_summary": {
            "high_risk": len([a for a in alerts if a["risk_assessment"]["risk_level"] == "HIGH"]),
            "medium_risk": len([a for a in alerts if a["risk_assessment"]["risk_level"] == "MEDIUM"]),
            "low_risk": len([a for a in alerts if a["risk_assessment"]["risk_level"] == "LOW"]),
        },
    }


def score_single_transaction(user_id: str, transaction: dict) -> dict:
    """Score a single transaction for anomaly."""
    detector = _ensure_anomaly_detector(user_id)
    return detector.score_transaction(transaction)


def get_spending_breakdown(user_id: str) -> dict:
    """Get spending breakdown by category."""
    mock_txns = _ensure_mock_data(user_id)
    summary = compute_income_summary(mock_txns)

    spending = summary.get("spending_by_category", {})
    total_spending = summary.get("total_spending", 0)

    categories = []
    for cat, amount in sorted(spending.items(), key=lambda x: -x[1]):
        categories.append({
            "category": cat,
            "amount": amount,
            "percentage": round(amount / max(total_spending, 1) * 100, 1),
        })

    return {
        "total_spending": total_spending,
        "categories": categories,
        "top_category": categories[0]["category"] if categories else "NONE",
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL REGISTRY (for LangGraph)
# ═══════════════════════════════════════════════════════════════════════════════

TOOL_DESCRIPTIONS = {
    "get_account_balance": "Get all savings account balances for the user",
    "get_transaction_history": "Get recent transaction history from the bank database",
    "get_user_profile": "Get user profile including name, email, KYC status",
    "get_card_status": "Get all cards and their current status (active/frozen/etc)",
    "freeze_card": "Emergency freeze a card to prevent unauthorized transactions",
    "create_security_notification": "Send a security alert notification to the user",
    "get_loan_status": "Get all active loans with EMI and outstanding details",
    "get_income_summary": "Analyze income patterns from gig work (Grab rides, deliveries)",
    "predict_income": "Predict future income for the next N days using ML model",
    "can_afford_day_off": "Analyze whether the user can financially afford to take a day off",
    "get_savings_recommendation": "Get personalized savings target and strategy",
    "detect_anomalies": "Run ML-based anomaly detection on all recent transactions",
    "score_single_transaction": "Score a specific transaction for fraud risk",
    "get_spending_breakdown": "Get spending breakdown by category (fuel, meals, rent, etc.)",
}
