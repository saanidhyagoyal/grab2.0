"""
FraudShield Agent — AI-Powered Fraud Mitigation Agent.
Monitors transactions, detects anomalies, and takes
autonomous protective actions while logging reasoning.
"""

from datetime import datetime
from typing import Optional

from com.gxs.bank.agent.reasoning_logger import ReasoningLogger, ReasoningSession
from com.gxs.bank.agent import tools
from com.gxs.bank.agent.llm_client import get_llm_client
from com.gxs.bank.agent.memory import get_memory


class FraudShieldAgent:
    """AI-Powered Fraud Mitigation Agent — LLM-enhanced with rule-based fallback."""

    def __init__(self, user_id: str):
        self.user_id = user_id
        self.logger = ReasoningLogger()
        self.llm = get_llm_client()
        self.memory = get_memory()

    def handle_query(self, query: str, session: Optional[ReasoningSession] = None) -> dict:
        """Handle fraud-related user queries."""
        if session is None:
            session = self.logger.create_session(self.user_id, query, "fraudshield_chat")

        query_lower = query.lower()

        session.add_step(
            action="Classify Fraud Query Intent",
            reasoning=f"Analyzing security-related query: '{query}'",
            tools_used=["intent_classifier"],
            agent_name="FraudShield",
        )

        if any(kw in query_lower for kw in ["scan", "check", "monitor", "analyze", "detect", "suspicious"]):
            return self._full_scan(session)
        elif any(kw in query_lower for kw in ["freeze", "block", "stop", "lock"]):
            return self._handle_freeze_request(session)
        elif any(kw in query_lower for kw in ["alert", "notification", "warn"]):
            return self._get_alerts(session)
        elif any(kw in query_lower for kw in ["safe", "secure", "status", "protected"]):
            return self._security_status(session)
        elif any(kw in query_lower for kw in ["recover", "compromised", "hacked", "stolen"]):
            return self._recovery_guide(session)
        else:
            return self._full_scan(session)

    def run_proactive_scan(self) -> dict:
        """
        Run a proactive fraud scan (called automatically, not by user query).
        This is what makes the agent truly 'agentic' — it acts without being asked.
        """
        session = self.logger.create_session(
            self.user_id,
            "[PROACTIVE] Automated fraud monitoring scan",
            "fraud_scan",
        )
        return self._full_scan(session)

    def _full_scan(self, session: ReasoningSession) -> dict:
        """Run comprehensive fraud scan on all transactions."""

        # Step 1: Gather transaction data
        session.add_step(
            action="Fetch Transaction History",
            reasoning="Retrieving recent transactions for anomaly analysis",
            tools_used=["get_transaction_history"],
            agent_name="FraudShield",
        )
        txn_data = tools.get_transaction_history(self.user_id)

        # Step 2: Run anomaly detection
        session.add_step(
            action="Run ML Anomaly Detection",
            reasoning=f"Analyzing {txn_data['count']} real transactions + mock gig data "
                      "using Isolation Forest model trained on user's normal behavior patterns",
            tools_used=["detect_anomalies"],
            agent_name="FraudShield",
        )
        anomaly_results = tools.detect_anomalies(self.user_id)

        # Step 3: Assess threat level
        high_risk = anomaly_results["risk_summary"]["high_risk"]
        medium_risk = anomaly_results["risk_summary"]["medium_risk"]
        total_anomalies = anomaly_results["anomalies_detected"]

        if high_risk > 0:
            threat_level = "CRITICAL"
            color = "🔴"
        elif medium_risk > 0:
            threat_level = "ELEVATED"
            color = "🟡"
        else:
            threat_level = "NORMAL"
            color = "🟢"

        session.add_step(
            action="Assess Threat Level",
            reasoning=f"Analyzed {anomaly_results['total_transactions_analyzed']} transactions. "
                      f"Found {total_anomalies} anomalies "
                      f"({high_risk} HIGH, {medium_risk} MEDIUM). "
                      f"Threat level: {threat_level}",
            tools_used=[],
            result={
                "threat_level": threat_level,
                "anomalies": total_anomalies,
                "high_risk": high_risk,
            },
            agent_name="FraudShield",
        )

        # Step 4: Take protective actions if needed
        actions_taken = []
        if high_risk > 0:
            session.add_step(
                action="Initiate Protective Measures",
                reasoning=f"HIGH risk detected ({high_risk} alerts). "
                          "Proceeding to: (1) Flag suspicious transactions, "
                          "(2) Create security notification, (3) Recommend card freeze",
                tools_used=["create_security_notification"],
                agent_name="FraudShield",
            )

            # Create security notification
            alert_desc = anomaly_results["alerts"][0]["transaction"]["description"] if anomaly_results["alerts"] else "Suspicious activity"
            tools.create_security_notification(
                self.user_id,
                "⚠️ Suspicious Activity Detected",
                f"FraudShield has detected {high_risk} high-risk transaction(s). "
                f"Most recent: {alert_desc}. Please review your recent activity immediately.",
            )
            actions_taken.append("security_notification_sent")
            actions_taken.append("card_freeze_recommended")

        # Step 5: Build response
        response = f"{color} **FraudShield Security Scan Complete**\n\n"
        response += f"**Threat Level**: {threat_level}\n"
        response += f"**Transactions Analyzed**: {anomaly_results['total_transactions_analyzed']}\n"
        response += f"**Anomalies Detected**: {total_anomalies}\n\n"

        if anomaly_results["alerts"]:
            response += "**🚨 Flagged Transactions:**\n\n"
            for i, alert in enumerate(anomaly_results["alerts"][:5], 1):
                txn = alert["transaction"]
                risk = alert["risk_assessment"]
                risk_emoji = "🔴" if risk["risk_level"] == "HIGH" else "🟡" if risk["risk_level"] == "MEDIUM" else "🟢"
                response += (
                    f"  {i}. {risk_emoji} **{txn['description']}** — S${float(txn['amount']):,.2f}\n"
                    f"     Risk: {risk['risk_level']} (score: {risk['anomaly_score']})\n"
                    f"     Reasons: {'; '.join(risk['risk_factors'][:2])}\n\n"
                )

        if high_risk > 0:
            response += (
                "\n**⚡ Actions Taken:**\n"
                "  ✅ Security notification sent to your account\n"
                "  ⚠️ **Recommendation**: Freeze your debit card immediately\n"
                "  📋 Review flagged transactions and report any unauthorized ones\n"
            )
        elif medium_risk > 0:
            response += (
                "\n**💡 Recommendations:**\n"
                "  • Review flagged transactions at your convenience\n"
                "  • Enable transaction alerts for amounts > S$100\n"
                "  • Consider updating your card PIN\n"
            )
        else:
            response += "\n✅ No threats detected. Your accounts appear secure.\n"

        session.add_step(
            action="Deliver Security Report",
            reasoning=f"Scan complete. Threat level: {threat_level}. "
                      f"Actions taken: {actions_taken or 'none'}. "
                      f"Report delivered to user.",
            tools_used=[],
            result={"threat_level": threat_level, "actions": actions_taken},
            agent_name="FraudShield",
        )
        session.complete(response, actions=actions_taken or ["scan_completed"])

        return {
            "response": response,
            "data": {
                "threat_level": threat_level,
                "anomaly_results": anomaly_results,
                "actions_taken": actions_taken,
            },
            "reasoning_session_id": session.session_id,
            "agent": "FraudShield",
        }

    def _handle_freeze_request(self, session: ReasoningSession) -> dict:
        """Handle card freeze request."""
        session.add_step(
            action="Fetch Card Status",
            reasoning="Retrieving all cards to identify which ones to freeze",
            tools_used=["get_card_status"],
            agent_name="FraudShield",
        )
        cards = tools.get_card_status(self.user_id)

        active_cards = [c for c in cards["cards"] if c["status"] == "ACTIVE"]

        if not active_cards:
            response = "ℹ️ All your cards are already frozen or cancelled. No action needed."
            session.complete(response, actions=["no_action"])
            return {
                "response": response,
                "data": cards,
                "reasoning_session_id": session.session_id,
                "agent": "FraudShield",
            }

        session.add_step(
            action="Freeze Active Cards",
            reasoning=f"Found {len(active_cards)} active card(s). Proceeding to freeze for security.",
            tools_used=["freeze_card"],
            agent_name="FraudShield",
        )

        frozen = []
        for card in active_cards:
            result = tools.freeze_card(self.user_id, card["card_id"])
            if result.get("success"):
                frozen.append(card["last4"])

        tools.create_security_notification(
            self.user_id,
            "🔒 Card(s) Frozen",
            f"Cards ending {', '.join(frozen)} have been frozen for your protection. "
            "You can unfreeze them from your dashboard once you've verified your account security.",
        )

        response = f"🔒 **Cards Frozen Successfully**\n\n"
        for last4 in frozen:
            response += f"  ✅ Card ending **{last4}** — FROZEN\n"
        response += "\nTo unfreeze, go to your dashboard > Cards > Unfreeze.\n"
        response += "If you didn't request this, contact GXS support immediately."

        session.complete(response, actions=["cards_frozen", "notification_sent"])

        return {
            "response": response,
            "data": {"frozen_cards": frozen},
            "reasoning_session_id": session.session_id,
            "agent": "FraudShield",
        }

    def _get_alerts(self, session: ReasoningSession) -> dict:
        """Get current fraud alerts."""
        session.add_step(
            action="Check Active Alerts",
            reasoning="Running anomaly detection to check for new alerts",
            tools_used=["detect_anomalies"],
            agent_name="FraudShield",
        )
        anomalies = tools.detect_anomalies(self.user_id)

        if not anomalies["alerts"]:
            response = "✅ No active fraud alerts. Your account is secure."
        else:
            response = f"🚨 **{anomalies['anomalies_detected']} Active Alert(s)**\n\n"
            for i, alert in enumerate(anomalies["alerts"][:5], 1):
                txn = alert["transaction"]
                risk = alert["risk_assessment"]
                response += (
                    f"{i}. **{txn['description']}** — S${float(txn['amount']):,.2f} "
                    f"[{risk['risk_level']}]\n"
                )

        session.complete(response, actions=["alerts_retrieved"])
        return {
            "response": response,
            "data": anomalies,
            "reasoning_session_id": session.session_id,
            "agent": "FraudShield",
        }

    def _security_status(self, session: ReasoningSession) -> dict:
        """Show overall security status."""
        session.add_step(
            action="Compile Security Status",
            reasoning="Gathering card status, alerts, and account info for security overview",
            tools_used=["get_card_status", "detect_anomalies"],
            agent_name="FraudShield",
        )
        cards = tools.get_card_status(self.user_id)
        anomalies = tools.detect_anomalies(self.user_id)

        frozen_cards = [c for c in cards["cards"] if c["status"] == "FROZEN"]
        high_risk = anomalies["risk_summary"]["high_risk"]

        if high_risk > 0:
            status = "⚠️ AT RISK"
        elif frozen_cards:
            status = "🔒 PARTIALLY LOCKED"
        else:
            status = "✅ SECURE"

        response = f"🛡️ **Security Status: {status}**\n\n"
        response += f"**Cards**: {len(cards['cards'])} total, {len(frozen_cards)} frozen\n"
        response += f"**Alerts**: {anomalies['anomalies_detected']} anomalies detected\n"
        response += f"  🔴 High Risk: {anomalies['risk_summary']['high_risk']}\n"
        response += f"  🟡 Medium Risk: {anomalies['risk_summary']['medium_risk']}\n"
        response += f"  🟢 Low Risk: {anomalies['risk_summary']['low_risk']}\n\n"

        response += "**Security Checklist:**\n"
        response += "  ✅ Account password: Set\n"
        response += "  ✅ JWT authentication: Active\n"
        response += f"  {'✅' if not frozen_cards else '⚠️'} Cards: {'All active' if not frozen_cards else f'{len(frozen_cards)} frozen'}\n"
        response += f"  {'✅' if high_risk == 0 else '🔴'} Transaction monitoring: {'Clean' if high_risk == 0 else 'Alerts active'}\n"

        session.complete(response, actions=["security_status_check"])
        return {
            "response": response,
            "data": {
                "status": status,
                "cards": cards,
                "anomalies": anomalies["risk_summary"],
            },
            "reasoning_session_id": session.session_id,
            "agent": "FraudShield",
        }

    def _recovery_guide(self, session: ReasoningSession) -> dict:
        """Provide step-by-step fraud recovery guide."""
        session.add_step(
            action="Generate Recovery Plan",
            reasoning="User reports potential compromise. Generating comprehensive recovery steps.",
            tools_used=["get_card_status", "get_account_balance"],
            agent_name="FraudShield",
        )

        cards = tools.get_card_status(self.user_id)
        balance = tools.get_account_balance(self.user_id)

        active_cards = [c for c in cards["cards"] if c["status"] == "ACTIVE"]

        session.add_step(
            action="Auto-Freeze Active Cards",
            reasoning=f"Precautionary: freezing {len(active_cards)} active card(s) to prevent further unauthorized access",
            tools_used=["freeze_card"],
            agent_name="FraudShield",
        )

        frozen = []
        for card in active_cards:
            result = tools.freeze_card(self.user_id, card["card_id"])
            if result.get("success"):
                frozen.append(card["last4"])

        if frozen:
            tools.create_security_notification(
                self.user_id,
                "🚨 Emergency Card Freeze - Recovery Mode",
                f"All active cards have been frozen as a precaution. Cards: {', '.join(frozen)}. "
                "Please follow the recovery steps provided by FraudShield.",
            )

        response = "🚨 **Account Recovery Guide**\n\n"
        response += "Your safety is our top priority. Follow these steps:\n\n"
        response += "**Step 1: Cards Secured** ✅\n"
        if frozen:
            response += f"  All active cards frozen: {', '.join(frozen)}\n\n"
        else:
            response += "  All cards were already frozen/cancelled\n\n"

        response += "**Step 2: Review Recent Transactions** 🔍\n"
        response += "  Check your transaction history for any unauthorized activity.\n"
        response += f"  Current balance: S${balance['total_balance']:,.2f}\n\n"

        response += "**Step 3: Change Your Credentials** 🔑\n"
        response += "  • Change your app password immediately\n"
        response += "  • Update your email password\n"
        response += "  • Enable 2-factor authentication\n\n"

        response += "**Step 4: Report to GXS Bank** 📞\n"
        response += "  • Call: +65 3138 9388 (24/7 hotline)\n"
        response += "  • Email: security@gxs.com.sg\n"
        response += "  • Report via app: Dashboard > Contact > Report Fraud\n\n"

        response += "**Step 5: Monitor** 👀\n"
        response += "  • FraudShield will continue monitoring your account\n"
        response += "  • You'll receive alerts for any new activity\n"
        response += "  • Unfreeze cards only after investigation is complete\n"

        session.complete(response, actions=["emergency_freeze", "recovery_guide_sent", "notification_sent"])

        return {
            "response": response,
            "data": {
                "cards_frozen": frozen,
                "current_balance": balance["total_balance"],
            },
            "reasoning_session_id": session.session_id,
            "agent": "FraudShield",
        }
