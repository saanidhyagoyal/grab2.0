"""
Conversation Memory — In-memory conversation store for the Agentic Platform.
Stores recent conversation turns per user to enable context-aware follow-up queries.
"""

from datetime import datetime
from collections import defaultdict
from typing import Optional


class ConversationMemory:
    """
    In-memory conversation store.
    Maintains a sliding window of recent messages per user.
    Thread-safe for concurrent access via single-threaded uvicorn worker.
    """

    MAX_TURNS_PER_USER = 10  # Keep last 10 conversation turns (5 user + 5 agent)

    def __init__(self):
        self._store: dict[str, list[dict]] = defaultdict(list)

    def add_message(self, user_id: str, role: str, content: str, metadata: dict = None):
        """
        Add a message to the conversation history.

        Args:
            user_id: The user's ID (str)
            role: "user" or "agent"
            content: The message content
            metadata: Optional extra data (agent name, intent, etc.)
        """
        uid = str(user_id)
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.utcnow().isoformat(),
        }
        if metadata:
            message["metadata"] = metadata

        self._store[uid].append(message)

        # Trim to max turns
        if len(self._store[uid]) > self.MAX_TURNS_PER_USER * 2:
            self._store[uid] = self._store[uid][-(self.MAX_TURNS_PER_USER * 2):]

    def get_history(self, user_id: str, limit: int = None) -> list:
        """
        Get conversation history for a user.

        Args:
            user_id: The user's ID
            limit: Optional max number of messages to return

        Returns:
            List of message dicts with role, content, timestamp
        """
        uid = str(user_id)
        history = self._store.get(uid, [])
        if limit:
            return history[-limit:]
        return history

    def get_context_summary(self, user_id: str) -> str:
        """
        Get a brief text summary of recent conversation for prompting.
        Useful for passing to LLM as context.
        """
        history = self.get_history(user_id, limit=6)
        if not history:
            return ""

        lines = []
        for msg in history:
            role = "User" if msg["role"] == "user" else "Agent"
            content = msg["content"][:100]
            lines.append(f"{role}: {content}")

        return "\n".join(lines)

    def clear(self, user_id: str):
        """Clear conversation history for a user."""
        uid = str(user_id)
        if uid in self._store:
            del self._store[uid]

    def clear_all(self):
        """Clear all conversation histories (e.g., on server restart)."""
        self._store.clear()

    def get_turn_count(self, user_id: str) -> int:
        """Get number of conversation turns for a user."""
        uid = str(user_id)
        return len(self._store.get(uid, []))


# Singleton instance
_memory = None


def get_memory() -> ConversationMemory:
    """Get the singleton conversation memory instance."""
    global _memory
    if _memory is None:
        _memory = ConversationMemory()
    return _memory
