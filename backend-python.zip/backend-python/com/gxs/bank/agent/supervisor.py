"""
Supervisor Agent — Routes user queries to FinWell or FraudShield agents.
This is the main entry point for all agent interactions.

Architecture:
  User Query → Supervisor → [FinWell Agent | FraudShield Agent] → Response + Reasoning Log

The Supervisor:
1. Classifies intent (financial wellness vs security/fraud)
2. Routes to the appropriate sub-agent
3. Maintains unified reasoning session across agents
4. Handles cross-domain queries (e.g., "my income dropped and I see suspicious charges")
"""

from datetime import datetime
from typing import Optional

from com.gxs.bank.agent.finwell_agent import FinWellAgent
from com.gxs.bank.agent.fraudshield_agent import FraudShieldAgent
from com.gxs.bank.agent.reasoning_logger import ReasoningLogger, ReasoningSession
from com.gxs.bank.agent.llm_client import get_llm_client
from com.gxs.bank.agent.memory import get_memory


class SupervisorAgent:
    """
    Orchestrates between FinWell and FraudShield agents.
    Implements the 'brain' of the agentic system.
    Uses LLM for intent classification when available, falls back to keyword matching.
    """

    def __init__(self, user_id: str):
        self.user_id = user_id
        self.finwell = FinWellAgent(user_id)
        self.fraudshield = FraudShieldAgent(user_id)
        self.logger = ReasoningLogger()
        self.llm = get_llm_client()
        self.memory = get_memory()

    def chat(self, query: str) -> dict:
        """
        Main entry point for agent chat.
        Routes to appropriate sub-agent based on intent classification.
        Stores conversation in memory for follow-up context.
        """
        session = self.logger.create_session(self.user_id, query, "chat")

        # Store user message in memory
        self.memory.add_message(self.user_id, "user", query)
        conversation_history = self.memory.get_history(self.user_id)

        # Check for greeting first
        if self._is_greeting(query):
            result = self._handle_greeting(session)
            result["intent"] = {"primary_intent": "greeting", "route_to": "Supervisor", "confidence": "HIGH", "llm_classified": False}
            result["reasoning_log"] = session.to_dict()
            self.memory.add_message(self.user_id, "agent", result.get("response", ""))
            return result

        # Step 1: Intent classification (LLM-powered or keyword-based)
        intent = self._classify_intent(query, conversation_history)
        classification_method = "LLM (Gemini)" if intent.get("llm_classified") else "keyword-matching"

        session.add_step(
            action="Intent Classification",
            reasoning=f"Analyzed query: '{query}' using {classification_method}. "
                      f"Classified as '{intent['primary_intent']}' domain "
                      f"(confidence: {intent['confidence']}). "
                      f"Routing to: {intent['route_to']} agent.",
            tools_used=["intent_classifier", classification_method],
            input_data={"query": query},
            result=intent,
            agent_name="Supervisor",
        )

        # Step 2: Route to appropriate agent
        if intent["route_to"] == "FraudShield":
            result = self.fraudshield.handle_query(query, session)
        elif intent["route_to"] == "both":
            result = self._handle_cross_domain(query, session)
        else:
            result = self.finwell.handle_query(query, session)

        # Step 3: Wrap with supervisor metadata
        result["intent"] = intent
        result["reasoning_log"] = session.to_dict()

        # Store agent response in memory
        self.memory.add_message(self.user_id, "agent", result.get("response", ""))

        return result

    def _is_greeting(self, query: str) -> bool:
        """Detect if the query is a simple greeting."""
        greetings = ["hi", "hello", "hey", "hola", "good morning", "good afternoon",
                     "good evening", "sup", "what's up", "howdy", "yo"]
        q = query.lower().strip().rstrip('!?.,')
        return q in greetings or (len(q.split()) <= 3 and any(g in q for g in greetings))

    def _handle_greeting(self, session) -> dict:
        """Return a personalized greeting with a quick financial snapshot."""
        from com.gxs.bank.agent import tools

        session.add_step(
            action="Greeting Detection",
            reasoning="User sent a greeting. Generating personalized welcome with financial snapshot.",
            tools_used=["get_account_balance", "get_user_profile"],
            agent_name="Supervisor",
        )

        try:
            profile = tools.get_user_profile(self.user_id)
            balance = tools.get_account_balance(self.user_id)
            name = profile.get("name", "there")
            bal = balance.get("total_balance", 0)

            response = (
                f"👋 Hey {name}! Great to see you.\n\n"
                f"**Quick snapshot:**\n"
                f"• 💰 Balance: **S${bal:,.2f}**\n"
                f"• 🛡️ Security: Active & monitoring\n\n"
                f"What would you like to know? I can help with income forecasts, "
                f"spending analysis, savings advice, or run a security scan."
            )
        except Exception:
            response = (
                "👋 Hey! I'm your AI Financial Assistant.\n\n"
                "I can help with:\n"
                "• 💰 Income analysis & predictions\n"
                "• 📊 Spending insights\n"
                "• 🛡️ Security scans\n\n"
                "What would you like to know?"
            )

        session.complete(response, actions=["greeting_response"])

        return {
            "response": response,
            "data": {},
            "reasoning_session_id": session.session_id,
            "agent": "Supervisor",
        }

    def get_proactive_insights(self) -> dict:
        """
        Generate proactive insights without user query.
        This runs periodically to provide unsolicited valuable advice.
        """
        session = self.logger.create_session(
            self.user_id,
            "[PROACTIVE] Generating financial insights",
            "proactive_insight",
        )

        session.add_step(
            action="Initiate Proactive Analysis",
            reasoning="Running scheduled proactive analysis to generate valuable insights "
                      "across both financial wellness and security domains",
            tools_used=[],
            agent_name="Supervisor",
        )

        # Get financial data
        from com.gxs.bank.agent import tools

        income = tools.get_income_summary(self.user_id)
        prediction = tools.predict_income(self.user_id, 7)
        balance = tools.get_account_balance(self.user_id)
        anomalies = tools.detect_anomalies(self.user_id)

        insights = []

        # Income trend insight
        if prediction["trend"] == "DECLINING":
            insights.append({
                "type": "warning",
                "title": "📉 Income Declining",
                "message": f"Your Grab earnings have been trending down. {prediction['trend_description']}. "
                           "Consider working peak hours (6-9 PM) or signing up for GrabFood shifts.",
                "category": "income",
                "priority": "high",
            })
        elif prediction["trend"] == "GROWING":
            insights.append({
                "type": "positive",
                "title": "📈 Income Growing",
                "message": f"Great news! {prediction['trend_description']}. "
                           "This is a good time to increase your savings allocation.",
                "category": "income",
                "priority": "medium",
            })

        # Balance alert
        if balance["total_balance"] < 500:
            insights.append({
                "type": "critical",
                "title": "⚠️ Low Balance Alert",
                "message": f"Your balance is S${balance['total_balance']:,.2f}. "
                           "Consider taking extra shifts this week to rebuild your buffer.",
                "category": "balance",
                "priority": "critical",
            })

        # Savings rate insight
        if income["savings_rate"] < 10:
            insights.append({
                "type": "warning",
                "title": "💰 Savings Rate Low",
                "message": f"Your savings rate is {income['savings_rate']}%. "
                           "Even S$10/day in savings adds up to S$300/month!",
                "category": "savings",
                "priority": "high",
            })

        # Security insight
        high_risk = anomalies["risk_summary"]["high_risk"]
        if high_risk > 0:
            insights.append({
                "type": "critical",
                "title": "🚨 Security Alert",
                "message": f"{high_risk} suspicious transaction(s) detected. "
                           "Open FraudShield for a full security scan.",
                "category": "security",
                "priority": "critical",
            })
        else:
            insights.append({
                "type": "positive",
                "title": "🛡️ Account Secure",
                "message": "FraudShield monitoring is active. No threats detected.",
                "category": "security",
                "priority": "low",
            })

        # Weekly forecast
        insights.append({
            "type": "info",
            "title": "📊 Weekly Forecast",
            "message": f"Predicted income this week: S${prediction['total_predicted']:,.2f}. "
                       f"Best day to work: "
                       f"{max(prediction['predictions'], key=lambda x: x['predicted_income'])['day'] if prediction['predictions'] else 'N/A'}.",
            "category": "forecast",
            "priority": "medium",
        })

        session.add_step(
            action="Generate Proactive Insights",
            reasoning=f"Generated {len(insights)} insights across income, savings, security, and forecasting",
            tools_used=["get_income_summary", "predict_income", "get_account_balance", "detect_anomalies"],
            result={"insights_count": len(insights)},
            agent_name="Supervisor",
        )
        session.complete(
            f"Generated {len(insights)} proactive insights",
            actions=["proactive_insights_generated"],
        )

        return {
            "insights": insights,
            "reasoning_session_id": session.session_id,
            "reasoning_log": session.to_dict(),
        }

    def _classify_intent(self, query: str, conversation_history: list = None) -> dict:
        """
        Classify user query intent.
        Tries LLM first, falls back to keyword matching.
        """
        # Try LLM-based classification first
        if self.llm.is_available():
            llm_result = self.llm.classify_intent(query, conversation_history)
            if llm_result:
                domain = llm_result.get("domain", "finwell")
                if domain == "fraudshield":
                    route_to = "FraudShield"
                elif domain == "both":
                    route_to = "both"
                else:
                    route_to = "FinWell"
                return {
                    "primary_intent": llm_result.get("intent", "general_advice"),
                    "route_to": route_to,
                    "confidence": llm_result.get("confidence", "MEDIUM"),
                    "llm_classified": True,
                }

        # Fallback: keyword matching
        return self._keyword_classify(query)

    def _keyword_classify(self, query: str) -> dict:
        """
        Keyword-based intent classification (fallback).
        """
        query_lower = query.lower()

        fraud_keywords = [
            "fraud", "scam", "suspicious", "unauthorized", "hack", "stolen",
            "freeze", "block", "alert", "security", "threat", "anomaly",
            "detect", "risk", "compromised", "phish", "scan", "protect",
        ]

        finwell_keywords = [
            "income", "earn", "save", "saving", "budget", "spend", "expense",
            "balance", "day off", "afford", "loan", "emi", "goal", "target",
            "predict", "forecast", "advice", "coach", "help", "money",
            "invest", "tip", "recommend", "salary", "fuel", "rent",
            "financial", "plan", "set goal", "savings goal", "emergency fund",
        ]

        fraud_score = sum(1 for kw in fraud_keywords if kw in query_lower)
        finwell_score = sum(1 for kw in finwell_keywords if kw in query_lower)

        if fraud_score > 0 and finwell_score > 0:
            return {
                "primary_intent": "cross_domain",
                "route_to": "both",
                "confidence": "MEDIUM",
                "fraud_relevance": fraud_score,
                "finwell_relevance": finwell_score,
                "llm_classified": False,
            }
        elif fraud_score > finwell_score:
            return {
                "primary_intent": "security",
                "route_to": "FraudShield",
                "confidence": "HIGH" if fraud_score >= 2 else "MEDIUM",
                "fraud_relevance": fraud_score,
                "finwell_relevance": finwell_score,
                "llm_classified": False,
            }
        else:
            return {
                "primary_intent": "financial_wellness",
                "route_to": "FinWell",
                "confidence": "HIGH" if finwell_score >= 2 else "MEDIUM",
                "fraud_relevance": fraud_score,
                "finwell_relevance": finwell_score,
                "llm_classified": False,
            }

    def _handle_cross_domain(self, query: str, session: ReasoningSession) -> dict:
        """Handle queries that span both domains."""
        session.add_step(
            action="Cross-Domain Analysis",
            reasoning="Query touches both financial wellness and security. "
                      "Running both agents and combining results.",
            tools_used=[],
            agent_name="Supervisor",
        )

        finwell_result = self.finwell.handle_query(query)
        fraud_result = self.fraudshield.handle_query(query)

        combined_response = (
            "🧠 **Dual-Agent Analysis**\n\n"
            "---\n\n"
            f"**💰 Financial Wellness (FinWell):**\n{finwell_result['response']}\n\n"
            "---\n\n"
            f"**🛡️ Security (FraudShield):**\n{fraud_result['response']}"
        )

        session.add_step(
            action="Combine Agent Results",
            reasoning="Merged analysis from both FinWell and FraudShield agents into unified response",
            tools_used=[],
            result={
                "finwell_session": finwell_result.get("reasoning_session_id"),
                "fraudshield_session": fraud_result.get("reasoning_session_id"),
            },
            agent_name="Supervisor",
        )
        session.complete(combined_response, actions=["cross_domain_analysis"])

        return {
            "response": combined_response,
            "data": {
                "finwell": finwell_result.get("data"),
                "fraudshield": fraud_result.get("data"),
            },
            "reasoning_session_id": session.session_id,
            "agent": "Supervisor",
        }



