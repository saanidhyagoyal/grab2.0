"""
Income prediction model for gig economy workers.
Uses historical earnings data to forecast future income
with time-series analysis and seasonal pattern detection.

NOTE: Uses pure Python math instead of numpy to avoid segfaults
on macOS with system Python 3.9.6 + numpy ABI mismatches.
"""

import math
import random
from datetime import datetime, timedelta
from collections import defaultdict


def _mean(values):
    """Pure Python mean."""
    if not values:
        return 0
    return sum(values) / len(values)


def _polyfit_1(x_vals, y_vals):
    """Simple linear regression slope (pure Python). Returns (slope, intercept)."""
    n = len(x_vals)
    if n < 2:
        return 0, _mean(y_vals)
    x_mean = sum(x_vals) / n
    y_mean = sum(y_vals) / n
    num = sum((x - x_mean) * (y - y_mean) for x, y in zip(x_vals, y_vals))
    den = sum((x - x_mean) ** 2 for x in x_vals)
    if den == 0:
        return 0, y_mean
    slope = num / den
    intercept = y_mean - slope * x_mean
    return slope, intercept


class IncomePredictor:
    """
    Predicts gig worker income using historical patterns.
    Accounts for day-of-week effects, weekly trends, and seasonal variation.
    """

    def __init__(self):
        self.daily_averages = {}  # day_of_week -> avg_income
        self.weekly_totals = []
        self.overall_avg = 0
        self.trend_slope = 0  # Income trend (growing/declining)
        self.is_trained = False

    def train(self, transactions: list):
        """Train on historical income transactions."""
        daily_income = defaultdict(list)  # day_of_week -> list of daily totals
        date_income = defaultdict(float)  # date_str -> total income

        for txn in transactions:
            if txn.get("type") != "CREDIT":
                continue

            amount = float(txn.get("amount", 0))
            ts = txn.get("timestamp")
            if isinstance(ts, datetime):
                day_of_week = ts.weekday()
                date_key = ts.strftime("%Y-%m-%d")
                daily_income[day_of_week].append(amount)
                date_income[date_key] += amount

        if not date_income:
            self.is_trained = False
            return

        # Compute day-of-week averages
        for dow in range(7):
            amounts = daily_income.get(dow, [0])
            self.daily_averages[dow] = _mean(amounts) if amounts else 0

        # Compute weekly totals
        weekly = defaultdict(float)
        for date_str, amount in date_income.items():
            try:
                dt = datetime.strptime(date_str, "%Y-%m-%d")
                week_key = dt.strftime("%Y-W%U")
                weekly[week_key] += amount
            except ValueError:
                pass

        self.weekly_totals = [v for _, v in sorted(weekly.items())]

        # Compute trend (simple linear regression on weekly totals)
        if len(self.weekly_totals) >= 3:
            x = list(range(len(self.weekly_totals)))
            self.trend_slope, _ = _polyfit_1(x, self.weekly_totals)
        else:
            self.trend_slope = 0

        # Overall average
        all_daily = list(date_income.values())
        self.overall_avg = _mean(all_daily) if all_daily else 0

        self.is_trained = True

    def predict_next_days(self, num_days: int = 7) -> dict:
        """Predict income for the next N days."""
        if not self.is_trained:
            return {
                "predictions": [],
                "total_predicted": 0,
                "confidence": "LOW",
                "trend": "UNKNOWN",
            }

        predictions = []
        total = 0
        now = datetime.utcnow()

        for i in range(1, num_days + 1):
            future_date = now + timedelta(days=i)
            dow = future_date.weekday()
            base_income = self.daily_averages.get(dow, self.overall_avg)

            # Apply trend adjustment
            weeks_ahead = i / 7
            trend_adj = self.trend_slope * weeks_ahead / max(self.overall_avg, 1) * 100

            # Add noise for realistic prediction (pure Python)
            noise = random.gauss(0, 0.1)
            predicted = max(0, base_income * (1 + noise))

            predictions.append({
                "date": future_date.strftime("%Y-%m-%d"),
                "day": future_date.strftime("%A"),
                "predicted_income": round(predicted, 2),
                "confidence_range": {
                    "low": round(predicted * 0.7, 2),
                    "high": round(predicted * 1.3, 2),
                },
            })
            total += predicted

        # Determine trend direction
        if self.trend_slope > 5:
            trend = "GROWING"
            trend_desc = f"Your income is trending upward by ~S${abs(self.trend_slope):.0f}/week"
        elif self.trend_slope < -5:
            trend = "DECLINING"
            trend_desc = f"Your income is trending downward by ~S${abs(self.trend_slope):.0f}/week"
        else:
            trend = "STABLE"
            trend_desc = "Your income has been relatively stable"

        return {
            "predictions": predictions,
            "total_predicted": round(total, 2),
            "avg_daily_predicted": round(total / num_days, 2),
            "confidence": "HIGH" if len(self.weekly_totals) >= 4 else "MEDIUM",
            "trend": trend,
            "trend_description": trend_desc,
            "trend_slope_weekly": round(self.trend_slope, 2),
        }

    def predict_next_week(self) -> dict:
        """Convenience: predict next 7 days."""
        return self.predict_next_days(7)

    def predict_next_month(self) -> dict:
        """Convenience: predict next 30 days."""
        return self.predict_next_days(30)

    def can_afford_day_off(self, target_savings: float = 0, monthly_expenses: float = 2000) -> dict:
        """
        Analyze whether the gig worker can afford to take a day off.
        Considers predicted income, ongoing expenses, and savings goals.
        """
        weekly_prediction = self.predict_next_week()
        predicted_weekly = weekly_prediction["total_predicted"]
        weekly_expenses = monthly_expenses / 4.33

        surplus = predicted_weekly - weekly_expenses

        # Find the lowest-income day to recommend taking off
        predictions = weekly_prediction["predictions"]
        if predictions:
            sorted_days = sorted(predictions, key=lambda x: x["predicted_income"])
            best_day_off = sorted_days[0]  # Lowest earning day
            lost_income = best_day_off["predicted_income"]
        else:
            best_day_off = None
            lost_income = self.overall_avg

        can_afford = surplus > lost_income + target_savings / 4.33

        return {
            "can_afford": can_afford,
            "predicted_weekly_income": round(predicted_weekly, 2),
            "estimated_weekly_expenses": round(weekly_expenses, 2),
            "weekly_surplus": round(surplus, 2),
            "recommended_day_off": best_day_off["day"] if best_day_off else "Monday",
            "income_lost_by_day_off": round(lost_income, 2),
            "remaining_surplus_after_day_off": round(surplus - lost_income, 2),
            "advice": (
                f"Yes, you can take a day off! {best_day_off['day'] if best_day_off else 'Monday'} "
                f"is your lowest-earning day (predicted S${lost_income:.2f}). "
                f"You'll still have S${max(0, surplus - lost_income):.2f} surplus for the week."
            )
            if can_afford
            else (
                f"Taking a day off this week is tight. You'd lose ~S${lost_income:.2f} "
                f"and your weekly surplus is only S${surplus:.2f}. "
                "Consider waiting until a higher-earning week, or reducing discretionary spending."
            ),
        }

    def get_savings_recommendation(self, current_balance: float, target: float = 5000, months: int = 6) -> dict:
        """Recommend savings strategy based on income predictions."""
        monthly_pred = self.predict_next_month()
        monthly_income = monthly_pred["total_predicted"]
        monthly_target = (target - current_balance) / max(months, 1)

        recommended_pct = min(30, max(5, (monthly_target / max(monthly_income, 1)) * 100))

        return {
            "current_balance": round(current_balance, 2),
            "target_amount": round(target, 2),
            "target_months": months,
            "predicted_monthly_income": round(monthly_income, 2),
            "recommended_monthly_savings": round(monthly_target, 2),
            "recommended_savings_percentage": round(recommended_pct, 1),
            "on_track": monthly_income * (recommended_pct / 100) >= monthly_target,
            "advice": (
                f"Save S${monthly_target:.2f}/month ({recommended_pct:.0f}% of income) "
                f"to reach your goal of S${target:,.2f} in {months} months. "
                f"Based on your predicted monthly income of S${monthly_income:,.2f}, this is achievable."
            ),
        }
