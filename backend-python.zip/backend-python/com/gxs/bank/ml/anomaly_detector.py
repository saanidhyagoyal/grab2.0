"""
Anomaly detection model for financial transactions.
Uses rule-based scoring to detect unusual transaction patterns
that may indicate fraud.

NOTE: Pure Python implementation — no numpy/sklearn.
Avoids segfaults on macOS system Python 3.9.6.
"""

import math
from datetime import datetime
import warnings

warnings.filterwarnings("ignore", category=UserWarning)


def _mean(values):
    """Pure Python mean."""
    if not values:
        return 0
    return sum(values) / len(values)


def _std(values):
    """Pure Python standard deviation."""
    if len(values) < 2:
        return 0
    avg = _mean(values)
    variance = sum((x - avg) ** 2 for x in values) / len(values)
    return math.sqrt(variance)


class AnomalyDetector:
    """
    Detects anomalous transactions using rule-based scoring.
    Trained on a user's 'normal' transaction history,
    then scores new transactions for anomaly.
    """

    def __init__(self, use_ml=False):
        # Always use rule-based to avoid sklearn segfaults
        self.use_ml = False
        self.model = None
        self.scaler = None
        self.is_trained = False
        self.feature_means = {}

    def _extract_features(self, transaction: dict) -> list:
        """Extract numerical features from a transaction."""
        amount = float(transaction.get("amount", 0))

        # Time features
        ts = transaction.get("timestamp")
        if isinstance(ts, datetime):
            hour = ts.hour
            day_of_week = ts.weekday()
            is_weekend = 1 if day_of_week >= 5 else 0
            is_night = 1 if hour < 6 or hour > 22 else 0
        else:
            hour = 12
            day_of_week = 0
            is_weekend = 0
            is_night = 0

        # Transaction type encoding
        txn_type = transaction.get("type", "DEBIT")
        is_outgoing = 1 if txn_type in ("DEBIT", "TRANSFER_OUT", "POS_PURCHASE", "ATM_WITHDRAWAL", "BILL_PAYMENT") else 0

        # Channel risk encoding
        channel = transaction.get("channel", "NET_BANKING")
        channel_risk = {
            "NET_BANKING": 0.3,
            "MOBILE": 0.2,
            "UPI": 0.2,
            "ATM": 0.5,
            "IMPS": 0.4,
            "NEFT": 0.3,
            "RTGS": 0.6,
            "BRANCH": 0.1,
        }.get(channel, 0.3)

        # Category risk
        category = transaction.get("category", "OTHER")
        category_risk = {
            "FRAUD_SUSPICIOUS": 0.95,
            "GIG_INCOME_RIDE": 0.05,
            "GIG_INCOME_FOOD": 0.05,
            "GIG_INCOME_BONUS": 0.05,
            "FUEL": 0.1,
            "MEALS": 0.05,
            "GROCERIES": 0.05,
            "RENT": 0.1,
            "PHONE_BILL": 0.05,
            "VEHICLE_MAINTENANCE": 0.15,
            "TRANSPORT_TOPUP": 0.05,
        }.get(category, 0.3)

        return [
            amount,
            hour,
            day_of_week,
            is_weekend,
            is_night,
            is_outgoing,
            channel_risk,
            category_risk,
        ]

    def train(self, transactions: list):
        """Train the model on historical 'normal' transactions."""
        if len(transactions) < 10:
            self.is_trained = False
            return

        try:
            features = [self._extract_features(t) for t in transactions]
            amounts = [f[0] for f in features]
            hours = [f[1] for f in features]

            # Store means for deviation calculation (pure Python)
            self.feature_means = {
                "avg_amount": _mean(amounts),
                "avg_hour": _mean(hours),
                "std_amount": _std(amounts) + 1e-6,
            }
            # Rule-based mode — feature_means computed, no sklearn needed
            self.is_trained = False
        except Exception as e:
            print(f"[AnomalyDetector] ⚠️ Training failed (falling back to rule-based): {e}")
            self.is_trained = False

    def score_transaction(self, transaction: dict) -> dict:
        """
        Score a single transaction for anomaly.
        Returns a dict with:
          - anomaly_score: 0.0 (normal) to 1.0 (highly anomalous)
          - is_anomaly: boolean
          - risk_factors: list of reasons
          - raw_score: inverted score
        """
        features = self._extract_features(transaction)
        return self._rule_based_score(transaction, features)

    def _rule_based_score(self, transaction: dict, features: list) -> dict:
        """Rule-based scoring — always works, no native dependencies."""
        risk_factors = []
        score = 0.0
        amount = float(transaction.get("amount", 0))

        # Amount-based checks
        if self.feature_means:
            avg = self.feature_means.get("avg_amount", 100)
            std = self.feature_means.get("std_amount", 50)
            deviation = abs(amount - avg) / max(std, 1)
            if deviation > 3:
                score += 0.3
                risk_factors.append(f"Amount S${amount:.2f} is {deviation:.1f}x std deviations from average (S${avg:.2f})")

        if amount > 1000:
            score += 0.2
            risk_factors.append(f"Large transaction amount: S${amount:.2f}")
        if amount > 5000:
            score += 0.3
            risk_factors.append("Transaction exceeds S$5,000 threshold")

        if features[4] == 1:
            score += 0.2
            risk_factors.append("Unusual timing (midnight to 6 AM)")

        category = transaction.get("category", "OTHER")
        if category == "FRAUD_SUSPICIOUS":
            score += 0.4
            risk_factors.append("Flagged by pattern matching")

        description = transaction.get("description", "").lower()
        for kw in ["unknown", "offshore", "crypto", "test", "foreign"]:
            if kw in description:
                score += 0.2
                risk_factors.append(f"Suspicious keyword in description: '{kw}'")
                break

        score = min(1.0, score)

        return {
            "anomaly_score": round(score, 3),
            "is_anomaly": score > 0.5,
            "risk_level": "HIGH" if score > 0.75 else "MEDIUM" if score > 0.5 else "LOW",
            "risk_factors": risk_factors if risk_factors else ["Transaction appears normal"],
            "raw_score": round(-score, 4),
        }

    def batch_score(self, transactions: list) -> list:
        """Score a batch of transactions."""
        return [self.score_transaction(t) for t in transactions]
