"""
Mock data generator for gig economy worker financial profiles.
Generates realistic Grab driver/delivery partner transaction data
with income variability, spending patterns, and fraud scenarios.
"""

from datetime import datetime, timedelta
from decimal import Decimal
import random
import time
import math


# ── Income patterns for gig workers ─────────────────────────────────────────

GRAB_RIDE_MERCHANTS = [
    "GrabRide Earnings", "GrabRide - Peak Hours", "GrabRide - Airport Trip",
    "GrabRide - Long Distance", "GrabRide - Night Shift",
]

GRAB_FOOD_MERCHANTS = [
    "GrabFood Delivery", "GrabFood - Incentive Bonus", "GrabFood - Peak Bonus",
    "GrabFood - Multi-order Batch", "GrabFood - Express Delivery",
]

SPENDING_CATEGORIES = {
    "FUEL": {
        "merchants": ["Shell Petrol", "Esso Station", "Caltex Fuel", "SPC Station"],
        "range": (30, 80),
        "frequency_per_week": (3, 5),
    },
    "MEALS": {
        "merchants": ["Kopitiam", "Hawker Centre Meal", "7-Eleven Snacks", "McDonald's", "Old Chang Kee"],
        "range": (4, 15),
        "frequency_per_week": (5, 10),
    },
    "PHONE_BILL": {
        "merchants": ["Singtel Mobile Plan", "StarHub Mobile", "M1 Mobile"],
        "range": (25, 55),
        "frequency_per_week": (0, 0),  # Monthly
    },
    "RENT": {
        "merchants": ["HDB Rental Payment", "Room Rental - Jurong", "Co-living Space Rent"],
        "range": (600, 1200),
        "frequency_per_week": (0, 0),  # Monthly
    },
    "VEHICLE_MAINTENANCE": {
        "merchants": ["AutoMaster Service", "Tyres Plus SG", "CarCare Workshop"],
        "range": (50, 300),
        "frequency_per_week": (0, 0),  # As-needed
    },
    "GROCERIES": {
        "merchants": ["FairPrice", "Giant Supermarket", "Sheng Siong"],
        "range": (20, 80),
        "frequency_per_week": (1, 3),
    },
    "TRANSPORT_TOPUP": {
        "merchants": ["EZ-Link TopUp", "SimplyGo TopUp"],
        "range": (10, 50),
        "frequency_per_week": (0, 1),
    },
}

# ── Fraud scenario templates ────────────────────────────────────────────────

FRAUD_SCENARIOS = [
    {
        "name": "unusual_large_transfer",
        "description": "Large unexpected outward transfer at unusual hour (3 AM)",
        "amount_range": (3000, 8000),
        "hour": 3,
        "merchant": "Unknown Overseas Transfer",
        "channel": "NET_BANKING",
        "type": "TRANSFER_OUT",
    },
    {
        "name": "rapid_small_transactions",
        "description": "Multiple small rapid transactions (card testing pattern)",
        "amount_range": (1, 5),
        "count": 6,
        "merchant": "Online Store Test",
        "channel": "MOBILE",
        "type": "POS_PURCHASE",
    },
    {
        "name": "foreign_high_risk",
        "description": "Transaction from high-risk foreign merchant",
        "amount_range": (500, 2000),
        "hour": 2,
        "merchant": "Offshore Crypto Exchange",
        "channel": "NET_BANKING",
        "type": "TRANSFER_OUT",
    },
    {
        "name": "duplicate_beneficiary",
        "description": "Multiple transfers to newly added beneficiary in short period",
        "amount_range": (800, 2500),
        "count": 3,
        "merchant": "Transfer to New Beneficiary",
        "channel": "IMPS",
        "type": "TRANSFER_OUT",
    },
]


def generate_daily_gig_income(day_of_week: int, base_daily: float = 120.0) -> list:
    """
    Generate realistic daily income for a Grab driver.
    Weekend / weekday variation, random variability.
    """
    entries = []

    # Weekend multiplier
    if day_of_week in (5, 6):  # Sat/Sun
        multiplier = random.uniform(1.3, 1.7)
    elif day_of_week == 4:  # Friday
        multiplier = random.uniform(1.1, 1.4)
    else:
        multiplier = random.uniform(0.7, 1.1)

    # Number of ride sessions
    num_rides = random.randint(3, 8)
    for _ in range(num_rides):
        ride_amount = round(base_daily / 5 * multiplier * random.uniform(0.5, 2.0), 2)
        merchant = random.choice(GRAB_RIDE_MERCHANTS)
        entries.append({
            "type": "CREDIT",
            "amount": str(ride_amount),
            "description": merchant,
            "channel": "MOBILE",
            "category": "GIG_INCOME_RIDE",
        })

    # GrabFood deliveries (some days only)
    if random.random() > 0.3:
        num_deliveries = random.randint(2, 6)
        for _ in range(num_deliveries):
            delivery_amount = round(random.uniform(8, 25) * multiplier, 2)
            merchant = random.choice(GRAB_FOOD_MERCHANTS)
            entries.append({
                "type": "CREDIT",
                "amount": str(delivery_amount),
                "description": merchant,
                "channel": "MOBILE",
                "category": "GIG_INCOME_FOOD",
            })

    # Incentive bonus (some days)
    if random.random() > 0.6:
        bonus = round(random.uniform(15, 50), 2)
        entries.append({
            "type": "CREDIT",
            "amount": str(bonus),
            "description": "GrabRide - Daily Incentive Bonus",
            "channel": "MOBILE",
            "category": "GIG_INCOME_BONUS",
        })

    return entries


def generate_daily_spending(day_of_week: int) -> list:
    """Generate realistic daily spending for a gig worker."""
    entries = []

    for category, config in SPENDING_CATEGORIES.items():
        freq_low, freq_high = config["frequency_per_week"]

        if freq_low == 0 and freq_high == 0:
            continue  # Monthly items handled separately

        # Calculate daily probability from weekly frequency
        daily_prob = random.uniform(freq_low, freq_high) / 7.0

        if random.random() < daily_prob:
            amount = round(random.uniform(*config["range"]), 2)
            merchant = random.choice(config["merchants"])
            entries.append({
                "type": "DEBIT",
                "amount": str(amount),
                "description": merchant,
                "channel": random.choice(["MOBILE", "NET_BANKING", "UPI"]),
                "category": category,
            })

    return entries


def generate_monthly_bills(month_day: int) -> list:
    """Generate monthly recurring bills (rent, phone, etc.)."""
    entries = []

    # Rent on the 1st
    if month_day == 1:
        rent_config = SPENDING_CATEGORIES["RENT"]
        entries.append({
            "type": "DEBIT",
            "amount": str(round(random.uniform(*rent_config["range"]), 2)),
            "description": random.choice(rent_config["merchants"]),
            "channel": "NET_BANKING",
            "category": "RENT",
        })

    # Phone bill around the 15th
    if 14 <= month_day <= 16:
        phone_config = SPENDING_CATEGORIES["PHONE_BILL"]
        entries.append({
            "type": "DEBIT",
            "amount": str(round(random.uniform(*phone_config["range"]), 2)),
            "description": random.choice(phone_config["merchants"]),
            "channel": "NET_BANKING",
            "category": "PHONE_BILL",
        })

    # Vehicle maintenance randomly
    if random.random() < 0.03:  # ~1x per month
        maint_config = SPENDING_CATEGORIES["VEHICLE_MAINTENANCE"]
        entries.append({
            "type": "DEBIT",
            "amount": str(round(random.uniform(*maint_config["range"]), 2)),
            "description": random.choice(maint_config["merchants"]),
            "channel": "NET_BANKING",
            "category": "VEHICLE_MAINTENANCE",
        })

    return entries


def generate_transaction_history(days: int = 60) -> list:
    """
    Generate a full transaction history for a gig worker over N days.
    Returns list of transaction dicts sorted by date (oldest first).
    """
    transactions = []
    running_balance = 5000.0  # Starting balance
    now = datetime.utcnow()

    for day_offset in range(days, 0, -1):
        current_date = now - timedelta(days=day_offset)
        day_of_week = current_date.weekday()
        month_day = current_date.day

        # Some days the driver takes off
        takes_day_off = random.random() < 0.12  # ~12% chance

        if not takes_day_off:
            # Income
            income_entries = generate_daily_gig_income(day_of_week)
            for entry in income_entries:
                amount = float(entry["amount"])
                running_balance += amount
                entry["balance_after"] = str(round(running_balance, 2))
                entry["timestamp"] = current_date.replace(
                    hour=random.randint(7, 22),
                    minute=random.randint(0, 59),
                )
                transactions.append(entry)

        # Spending (even on off days)
        spending_entries = generate_daily_spending(day_of_week)
        for entry in spending_entries:
            amount = float(entry["amount"])
            running_balance -= amount
            if running_balance < 0:
                running_balance = 50.0  # Floor
            entry["balance_after"] = str(round(running_balance, 2))
            entry["timestamp"] = current_date.replace(
                hour=random.randint(8, 21),
                minute=random.randint(0, 59),
            )
            transactions.append(entry)

        # Monthly bills
        monthly_entries = generate_monthly_bills(month_day)
        for entry in monthly_entries:
            amount = float(entry["amount"])
            running_balance -= amount
            if running_balance < 0:
                running_balance = 50.0
            entry["balance_after"] = str(round(running_balance, 2))
            entry["timestamp"] = current_date.replace(hour=9, minute=0)
            transactions.append(entry)

    return transactions


def generate_fraud_transactions() -> list:
    """
    Generate a set of fraud-scenario transactions for demo purposes.
    These are injected alongside normal transactions for the fraud agent to detect.
    """
    fraud_txns = []
    now = datetime.utcnow()

    # Pick 2 random fraud scenarios for the demo
    chosen = random.sample(FRAUD_SCENARIOS, min(2, len(FRAUD_SCENARIOS)))

    for scenario in chosen:
        if scenario.get("count"):
            # Multiple rapid transactions
            for i in range(scenario["count"]):
                fraud_txns.append({
                    "type": scenario["type"],
                    "amount": str(round(random.uniform(*scenario["amount_range"]), 2)),
                    "description": f"{scenario['merchant']} #{i+1}",
                    "channel": scenario["channel"],
                    "category": "FRAUD_SUSPICIOUS",
                    "timestamp": now - timedelta(hours=random.randint(1, 4), minutes=i * 2),
                    "balance_after": "0",  # Will be computed
                    "fraud_scenario": scenario["name"],
                    "fraud_description": scenario["description"],
                })
        else:
            fraud_txns.append({
                "type": scenario["type"],
                "amount": str(round(random.uniform(*scenario["amount_range"]), 2)),
                "description": scenario["merchant"],
                "channel": scenario["channel"],
                "category": "FRAUD_SUSPICIOUS",
                "timestamp": now.replace(hour=scenario.get("hour", 3)),
                "balance_after": "0",
                "fraud_scenario": scenario["name"],
                "fraud_description": scenario["description"],
            })

    return fraud_txns


def compute_income_summary(transactions: list) -> dict:
    """Compute income summary from transaction list."""
    total_income = 0
    total_spending = 0
    income_by_category = {}
    spending_by_category = {}
    daily_income = {}

    for txn in transactions:
        amount = float(txn["amount"])
        category = txn.get("category", "OTHER")
        ts = txn.get("timestamp", datetime.utcnow())
        day_key = ts.strftime("%Y-%m-%d") if isinstance(ts, datetime) else str(ts)[:10]

        if txn["type"] == "CREDIT":
            total_income += amount
            income_by_category[category] = income_by_category.get(category, 0) + amount
            daily_income[day_key] = daily_income.get(day_key, 0) + amount
        elif txn["type"] in ("DEBIT", "TRANSFER_OUT", "POS_PURCHASE", "BILL_PAYMENT", "ATM_WITHDRAWAL"):
            total_spending += amount
            spending_by_category[category] = spending_by_category.get(category, 0) + amount

    avg_daily_income = total_income / max(len(daily_income), 1)

    # Weekly breakdown
    weekly_income = {}
    for day_str, amount in daily_income.items():
        try:
            dt = datetime.strptime(day_str, "%Y-%m-%d")
            week_key = dt.strftime("%Y-W%U")
            weekly_income[week_key] = weekly_income.get(week_key, 0) + amount
        except ValueError:
            pass

    return {
        "total_income": round(total_income, 2),
        "total_spending": round(total_spending, 2),
        "net_savings": round(total_income - total_spending, 2),
        "savings_rate": round((total_income - total_spending) / max(total_income, 1) * 100, 1),
        "avg_daily_income": round(avg_daily_income, 2),
        "income_by_category": {k: round(v, 2) for k, v in income_by_category.items()},
        "spending_by_category": {k: round(v, 2) for k, v in spending_by_category.items()},
        "daily_income": {k: round(v, 2) for k, v in sorted(daily_income.items())},
        "weekly_income": {k: round(v, 2) for k, v in sorted(weekly_income.items())},
    }
