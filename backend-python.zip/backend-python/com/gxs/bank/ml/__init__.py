# ML module for anomaly detection and income prediction
