class ResourceNotFoundException(Exception):
    pass
